﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int primo;
            int num;
            int a = 0;
            int n;

            Console.WriteLine("Ingrese un numero");
            num = int.Parse(Console.ReadLine());
            while (num < 0)
            {
                Console.Write("ERROR REINGRESE NUMERO :");
                num = int.Parse(Console.ReadLine());
            }
            for (i = 1; i <= num; i++)
            {
                for (n = 1; n <= i; n++)
                {
                    if (i%n == 0)
                    {
                        a++;
                    }

                }


                if (a == 2)
                {
                    Console.WriteLine(i);
                }
                a = 0;
            }
            Console.Read();

        }
    }
}
