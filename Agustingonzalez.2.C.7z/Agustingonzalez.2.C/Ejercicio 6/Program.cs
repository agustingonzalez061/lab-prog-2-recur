using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_6
{
  class Program
  {
    static void Main(string[] args)
    {
      int añoInicio,añoFin,i,condicion = 100;
      Console.WriteLine("Ingrese un año de inicio");
      if (int.TryParse(Console.ReadLine(), out añoInicio))
      {
        Console.WriteLine("Ingrese un año de fin");
        if (int.TryParse(Console.ReadLine(), out añoFin))
        {
          for(i= añoInicio -1; i <= añoFin; i ++)
          {
            if((i%4) == 0)
            {
              if (((i%400) == 0 && (i%condicion) == 0) || (i%condicion) != 0)
              Console.WriteLine("El año {0} es BISIESTO", i);
            }
          }
        }
      }
      Console.ReadKey();
    }
  }
}
