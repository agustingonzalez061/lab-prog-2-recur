﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ejercicio_27
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio con PILA");
            System.Collections.Stack pila = new System.Collections.Stack();
            List<int> positivos = new List<int>();
            List<int> negativos = new List<int>();
            Random rdm;
            int numero;
            for (int i = 0; i < 20; i++)
            {
                rdm = new Random();
                if ((numero = (rdm.Next(-100, 100))) != 0)
                {
                    pila.Push(numero);
                }
                else
                {
                    i--;
                }
                Thread.Sleep(100);
            }
            foreach (int item in pila)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros positivos");
            foreach (int item in pila)
            {
                if (item > 0)
                {
                    positivos.Add(item);
                }
            }
            positivos.Sort();
            positivos.Reverse();
            foreach (int item in positivos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros negativos");
            foreach (int item in pila)
            {
                if (item < 0)
                {
                    negativos.Add(item);
                }
            }
            negativos.Sort();
            foreach (int item in negativos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Ejercicio con COLA");
            System.Collections.Queue cola = new System.Collections.Queue();

            for (int i = 0; i < 20; i++)
            {
                rdm = new Random();
                if ((numero = (rdm.Next(-100, 100))) != 0)
                {
                    cola.Enqueue(numero);
                }
                else
                {
                    i--;
                }
                Thread.Sleep(100);
            }
            foreach (int item in cola)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros positivos");
            positivos.Clear();
            foreach (int item in cola)
            {
                if (item > 0)
                {
                    positivos.Add(item);
                }
            }
            positivos.Sort();
            positivos.Reverse();
            foreach (int item in positivos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros negativos");
            negativos.Clear();
            foreach (int item in cola)
            {
                if (item < 0)
                {
                    negativos.Add(item);
                }
            }
            negativos.Sort();
            foreach (int item in negativos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
