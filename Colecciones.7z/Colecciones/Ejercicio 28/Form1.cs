﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cadena = richTextBox1.Text;
            string[] separado;
            int contador;
            Dictionary<string, int> diccionario = new Dictionary<string,int>();
            separado = cadena.Split(' ');
            for(int i = 0; i< separado.Length; i ++)
            {
                contador = 0;
                for (int k = i + 1; k < separado.Length; k++)
                {
                    if (separado[i] == separado[k])
                    {
                        contador++;
                        if(k == (separado.Length - 1))
                        {
                            diccionario.Add(separado[i], contador);
                        }
                    }
                }
            }
            for (int i =0; i < diccionario.Count ; i ++)
            {
                int maximo = diccionario.Values.Max;
                string palabra;
                if

            }

        }
    }
}
