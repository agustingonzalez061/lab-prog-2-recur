﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ejercicio_26
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numeros = new List<int>();
            List<int> positivos = new List<int>();
            List<int> negativos = new List<int>();
            Random rdm;
            int numero;
            for (int i = 0; i < 20; i++)
            {
                rdm = new Random();
                if((numero =(rdm.Next(-100, 100)))!=0)
                {
                    numeros.Add(numero);
                }
                else
                {
                    i--;
                }
                Thread.Sleep(100);

            }
            foreach (int item in numeros)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros positivos");
            foreach (int item in numeros)
            {
                if(item > 0)
                {
                    positivos.Add(item);
                }
            }
            positivos.Sort();
            positivos.Reverse();
            foreach  (int item in positivos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Numeros negativos");
            foreach (int item in numeros)
            {
                if (item < 0)
                {
                    negativos.Add(item);
                }
            }
            negativos.Sort();
            foreach (int item in negativos)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
