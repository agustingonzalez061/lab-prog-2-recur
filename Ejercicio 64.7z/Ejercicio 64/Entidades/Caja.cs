﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Caja
    {
        private List<string> filaClientes;
        public List<string> FilaCliente
        {
            get
            {
                return this.filaClientes;
            }
        }
        public Caja ()
        {
            this.filaClientes = new List<string>();
        }
        public void AtenderClientes ()
        {
            for(int i = 0; i< filaClientes.Count; i ++)
            {
                Thread.Sleep(2000);
                Console.WriteLine("Cliente:{0}  Caja:{1}", this.filaClientes[i], Thread.CurrentThread.Name);
                this.filaClientes.Remove(this.filaClientes[i]);
                i--;
            }
        }
    }
}
