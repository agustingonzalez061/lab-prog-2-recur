using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
  public partial class ModificarProductoForm : Form
  {
    private Producto producto;
    private Comiqueria comiqueria;
    public ModificarProductoForm(Producto producto, Comiqueria comiqueria)
    {
      InitializeComponent();
      this.producto = producto;
      this.comiqueria = comiqueria;
      this.lblDescripcion.Text = producto.Descripcion;
      this.txtPrecioActual.Text = String.Format("${0:#,0.00}",producto.Precio);
    }

    private void btnCancelar_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void btnModificar_Click(object sender, EventArgs e)
    {
      double precio;
      if(Double.TryParse(this.txtNuevoPrecio.Text,out precio))
      {
        
       
        DialogResult result = MessageBox.Show("¿Desear continuar con la modificacion?", "Warning", MessageBoxButtons.YesNo);
        if (result == DialogResult.Yes)
        {
          producto.Precio = double.Parse(this.txtNuevoPrecio.Text);
          this.Close();
        }

      }
      else
      {
        this.lblError.Text = "Error.Debe ingresar un precio valido";
      }
    }
  }
}
