using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
  public partial class VentasForm : Form
  {
    private Producto producto;
    private Comiqueria comiqueria;
    public VentasForm(Producto producto, Comiqueria comiqueria)
    {      
      InitializeComponent();
      this.producto = producto;
      this.comiqueria = comiqueria;
      this.lblDescripcion.Text = producto.Descripcion;
      precio();
    }
    private void button2_Click(object sender, EventArgs e)
    {
      this.Close();
    }
    private void numericUpDownantidad_ValueChanged(object sender, EventArgs e)
    {
      precio();
    }
    private void precio()
    {
      double precio = Venta.CalcularPrecioFinal(producto.Precio, getCantidad());
      this.lblPrecioFinal.Text = (String.Format("${0:#,0.00}", precio));
    }

    private int getCantidad()
    {
      return Decimal.ToInt32(this.numericUpDownantidad.Value);
    }

    private void btnVender_Click(object sender, EventArgs e)
    {
       if (getCantidad() <= producto.Stock)
       {
         comiqueria.Vender(producto, getCantidad());
         this.DialogResult = DialogResult.OK;
       }
       else
       {
          MessageBox.Show("Cantidad insuficiente", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
       }
    }
  }
}
