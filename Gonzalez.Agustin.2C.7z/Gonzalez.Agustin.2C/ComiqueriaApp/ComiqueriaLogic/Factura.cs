using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComiqueriaLogic;

namespace ComprobantesLogic
{
  class Factura : Comprobante
  {
    public enum TipoFactura { A,B,C,D }

    private DateTime fechaVencimiento;
    private TipoFactura tipoFactura;
    /// <summary>
    /// Contructor de Factura que llama a la clase base
    /// </summary>
    /// <param name="venta"></param>
    /// <param name="diasParaVencimiento"></param>
    /// /// <param name="tipoFactura"></param>
    public Factura (Venta venta, int diasParaVencimiento, TipoFactura tipoFactura) :base (venta)
    {
      this.fechaVencimiento = DateTime.Now.AddDays(diasParaVencimiento);
      this.tipoFactura = tipoFactura;
    }
    public Factura (Venta venta, TipoFactura tipoFactura) : this (venta,15,tipoFactura)
    { }
    /// <summary>
    /// Sobrecarga del metodo de la clase base GENERARCOMPROBANTE
    /// </summary>
    public override string GenerarComprobante()
    {
      Producto p = (Producto)Venta;
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(String.Format("FACTURA: {0}", this.tipoFactura));
      sb.AppendLine(String.Format("Fecha Emision: {0}", this.fechaEmision));
      sb.AppendLine(String.Format("Fecha Vencimiento: {0}", this.fechaVencimiento));
      sb.AppendLine(String.Format("Producto: {0}", p.Descripcion));
      sb.AppendLine(String.Format("Cantidad: {0}", Venta.Cantidad));
      sb.AppendLine(String.Format("Precio Unitario: ${0:#,0.00}", p.Precio));
      sb.AppendLine(String.Format("Subtotal: ${0:#,0.00}", (p.Precio * Venta.Cantidad)));
      sb.AppendLine(String.Format("Importe IVA: ${0:#,0.00}", ((p.Precio * Venta.Cantidad)*0.21)));
      sb.AppendLine(String.Format("Importe Final: ${0:#,0.00}", Venta.CalcularPrecioFinal(p.Precio,Venta.Cantidad)));
      sb.AppendLine("------------------------------------------");
      return sb.ToString();
    }
    /// <summary>
    /// Sobrecarga del metodo EQUALS
    /// </summary>
    public override bool Equals(object obj)
    {
      if (base.Equals(obj) && ((Factura)obj).tipoFactura == this.tipoFactura)
      {
        return true;
      }
      return false;
    }
  }
}
