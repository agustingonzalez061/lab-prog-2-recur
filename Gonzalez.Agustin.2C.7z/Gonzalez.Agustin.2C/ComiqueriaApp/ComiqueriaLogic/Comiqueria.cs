using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> productos;
    private List<Venta> ventas;
    public Comiqueria ()
    {
      this.productos = new List<Producto>();
      this.ventas = new List<Venta>();
    }
    public Producto this[Guid codigo]
    {
      get
      {       
        foreach (Producto item in productos)
        {
          if (codigo == (Guid)item)
          {
            return item;
          }         
        }
        return null;
      }
    }
    public static bool operator ==(Comiqueria comiqueria,Producto producto)
    {
      bool valor = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item.Descripcion == producto.Descripcion)
            valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria == producto);
    }
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      bool esta = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item == producto)
            esta = true;
        }
        if (!esta)
          comiqueria.productos.Add(producto);
      }
      return comiqueria;
    }
    public void Vender (Producto producto)
    {
      Venta venta = new Venta(producto, 1);
      ventas.Add(venta);
    }
    public void Vender(Producto producto,int cantidad)
    {
      Venta venta = new Venta(producto, cantidad);
      ventas.Add(venta);
    }
    public string ListarVentas ()
    {
      StringBuilder sb = new StringBuilder();
      this.ventas.Sort();
      foreach (Venta item in this.ventas)
      {
        sb.AppendLine(item.ObtenerDescripcionBreve());
      }
      sb.AppendLine("------------------------------------------");
      return sb.ToString();
    }
    public Dictionary<Guid,string> ListarProductos()
    {
      StringBuilder sb = new StringBuilder();
      Dictionary<Guid, string> dic= new Dictionary<Guid, string>();
      foreach (Producto item in this.productos)
      {
        dic.Add((Guid)item, item.Descripcion);
        
      }
      return dic;
    }

  }
}
