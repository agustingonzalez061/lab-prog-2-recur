using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComprobantesLogic;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> productos;
    private List<Comprobante> lComprobantes;
    private List<Venta> ventas;
    private static Stack<Comprobante> comprobantes;

    /// <summary>
    /// Constructor encargado de inicializar las listas
    /// </summary>
    public Comiqueria ()
    {
      this.productos = new List<Producto>();
      this.ventas = new List<Venta>();
      this.lComprobantes = new List<Comprobante>();
    }
    /// <summary>
    /// Constructor encargado de iniciarlizar el STACK. 
    /// </summary>
    static Comiqueria ()
    {
      comprobantes = new Stack<Comprobante>();
    }
    /// <summary>
    /// Indexador que devuelve un producto segun el codigo ingresado por parametro. 
    /// </summary>
    /// <param name="codigo"></param>
    public Producto this[Guid codigo]
    {
      get
      {       
        foreach (Producto item in productos)
        {
          if (codigo == (Guid)item)
          {
            return item;
          }         
        }
        return null;
      }
    }
    //public List<Comprobante> this[Producto producto,bool ordenar]
    //{
      
    //  get
    //  {
        
    //    foreach (Comprobante item in comprobantes)
    //    {
    //      Producto p = (Producto)item.Venta;
    //      if ((Guid)p == (Guid)producto)
    //      {
    //        this.lComprobantes.Add(item);
    //      }
    //    }
    //    return null;
    //  }

    //}
    /// <summary>
    /// Sobrecarga del operador ==. 
    /// </summary>
    /// <param name="comiqueria"></param>
    /// <param name="producto"></param>
    public static bool operator ==(Comiqueria comiqueria,Producto producto)
    {
      bool valor = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item.Descripcion == producto.Descripcion)
            valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria == producto);
    }
    /// <summary>
    /// Sobrecarga del operador +. 
    /// </summary>
    /// <param name="comiqueria"></param>
    /// <param name="producto"></param>
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      bool esta = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item == producto)
            esta = true;
            break;
        }
        if (!esta)
          comiqueria.productos.Add(producto);
      }
      return comiqueria;
    }
    /// <summary>
    /// metodo encargado de realizar la venta de un producto. 
    /// </summary>
    /// <param name="vender"></param>
    public void Vender (Producto producto) 
    {
         Vender(producto, 1);
    }
    /// <summary>
    /// metodo encargado de realizar la venta de un producto. 
    /// </summary>
    /// <param name="vender"></param>
    /// <param name="cantidad"></param>
    public void Vender(Producto producto,int cantidad)
    {
      Venta venta = new Venta(producto, cantidad);
      ventas.Add(venta);
    }
    /// <summary>
    /// metodo encargado de listar las ventas 
    /// </summary>
    public string ListarVentas ()
    {
      StringBuilder sb = new StringBuilder();
      this.ventas.Sort(Comparar);
      foreach (Venta item in this.ventas)
      {
        sb.AppendLine(item.ObtenerDescripcionBreve());
      }
      sb.AppendLine("------------------------------------------");
      return sb.ToString();
    }
    private int Comparar(Venta v1, Venta v2)
    {
            if (v1.Fecha > v2.Fecha)
            {
                return 1;
            }
            else if (v1.Fecha < v2.Fecha)
            {
                return -1;
            }
            return 0;
        }
    public Dictionary<Guid,string> ListarProductos()
    {
      Dictionary<Guid, string> dic= new Dictionary<Guid, string>();
      foreach (Producto item in this.productos)
      {
        dic.Add((Guid)item, item.Descripcion);
        
      }
      return dic;
    }
    public static bool operator ==(Comiqueria comiqueria, Comprobante comprobante)
    {
      bool valor = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(comprobante, null))
      {
        foreach (Comprobante item in comprobantes)
        {
          if (item ==comprobante)
            valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Comiqueria comiqueria, Comprobante comprobante)
    {
      return !(comiqueria == comprobante);
    }
    public bool AgregarComprobante (Comprobante comprobante)
    {
      bool esta = false;
      bool retorno = false;
      if (!object.Equals(comprobante, null))
      {
        foreach (Comprobante item in comprobantes)
        {
          if (item == comprobante)
            esta = true;
          break;
        }
        if (!esta)
        { 
          comprobantes.Push(comprobante);
          retorno = true;
        }
        
      }
      return retorno;
    }
    private bool AgregarComprobante(Venta venta)
    {
      bool retorno = false;
      Factura factura = new Factura(venta, Factura.TipoFactura.B);
      if (AgregarComprobante(factura))
        retorno = true;
      return retorno;
    }
  }
}
