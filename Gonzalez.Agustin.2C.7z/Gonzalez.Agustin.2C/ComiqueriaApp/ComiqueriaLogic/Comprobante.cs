using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComiqueriaLogic;

namespace ComprobantesLogic
{
  public abstract class Comprobante
  {
    protected DateTime fechaEmision;
    private Venta venta;
    /// <summary>
    /// Propiedad Internal solo accesible desde el ensamblado
    /// </summary>
    internal Venta Venta
    {
      get
      {
        return this.venta;
      }
    }
    /// <summary>
    /// Constructor de la clase Comprobante
    /// </summary>
    /// <param name="venta"></param>

    public Comprobante (Venta venta)
    {
      this.fechaEmision = venta.Fecha;
    }
    /// <summary>
    /// Sobrecarga del metodo EQUALS
    /// </summary>
    public override bool Equals(object obj)
    {
      if(obj is Comprobante && ((Comprobante)obj).fechaEmision == this.fechaEmision)
      {
        return true;
      }
      return false;
    }
    /// <summary>
    /// Instanciamiento del metodo Abstracto GENERARCOMPROBANTE
    /// </summary>
    public abstract string GenerarComprobante();

  }
}
