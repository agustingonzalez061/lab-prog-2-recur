﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
    public class Centralita
    {
        private List<Llamada> listaDeLLamadas;
        protected string razonSocial;

        public float GananciasPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }
        public float GananciasPorProvincial
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }
        public float GananciasPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }
        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLLamadas;
            }
        }
        public Centralita()
        {
            this.listaDeLLamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }
        private float CalcularGanancia (Llamada.TipoLlamada tipo)
        {
            float ganancia = 0;
            switch (tipo)
            {
                case Llamada.TipoLlamada.Local:
                    foreach (Llamada item in listaDeLLamadas)
                    {
                        if (item is Local)
                        {
                            ganancia += ((Local)item).CostoLlamada;
                        }
                    }
                    break;
                case Llamada.TipoLlamada.Provincial:
                    foreach (Llamada item in listaDeLLamadas)
                    {
                        if (item is Provincial)
                        {
                            ganancia += ((Provincial)item).CostoLlamada;
                        }
                    }
                    break;
                case Llamada.TipoLlamada.Todas:
                    foreach (Llamada item in listaDeLLamadas)
                    {
                        if (item is Local)
                        {
                            ganancia += ((Local)item).CostoLlamada;
                        }
                    }
                    foreach (Llamada item in listaDeLLamadas)
                    {
                        if (item is Provincial)
                        {
                            ganancia += ((Provincial)item).CostoLlamada;
                        }
                    }
                    break;
                default:
                    break;
            }
            return ganancia;
        }
        
        public string Mostrar ()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Razon social:" + razonSocial);
            sb.AppendLine("Ganancia Total :" + GananciasPorTotal);
            sb.AppendLine("Ganancia Local :" + GananciasPorLocal);
            sb.AppendLine("Ganancia Provincial :" + GananciasPorProvincial);
            foreach (Llamada item in listaDeLLamadas)
            {
                if(item is Local)
                {
                    sb.AppendLine("Local:" + ((Local)item).Mostrar());
                }
                else
                    sb.AppendLine("Local:" + ((Provincial)item).Mostrar());
            }
            return sb.ToString();
        }
        public void OrdenarLlamadas ()
        {
            this.listaDeLLamadas.Sort(Llamada.OrdenarPorDuracion);
        }

    }
}
