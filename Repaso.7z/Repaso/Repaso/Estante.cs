﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Estante
    {
        private Producto[] productos;
        private int ubicacionEstante;

        private Estante(int capacidad)
        {
            productos = new Producto[capacidad];
        }
        public Estante (int capacidad, int ubicacion) : this (capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }
        public Producto [] GetProducto ()
        {
            return this.productos;
        }
        public static string MostrarEstante (Estante e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("ESTANTE");
            sb.AppendLine("Ubicacion :" + e.ubicacionEstante);
            for(int i = 0; i < e.productos.Length; i ++)
            {
                if(Object.ReferenceEquals(e.productos[i],null))
                {
                    Producto.MostrarProducto(e.productos[i]);
                }
            }
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        public static bool operator ==(Estante e, Producto p)
        {
            bool valor = false;
            if (!object.Equals(e, null) && !object.Equals(p, null))
            {
                for (int i = 0; i < e.productos.Length; i++)
                {
                    if (Object.ReferenceEquals(e.productos[i], null))
                    {
                        if(e.productos[i] == p)
                        {
                            valor = true;
                            break;
                        }
                    }
                }
            }
            return valor;
        }


        public static bool operator !=(Estante e, Producto p)
        {

            return !(e == p);
        }
        public static bool operator +(Estante e, Producto p)
        {
            bool retorno = false;
            if (!(e == p))
            {
                for (int i = 0; i < e.productos.Length; i++)
                {
                    if (Object.ReferenceEquals(e.productos[i], null))
                    {
                        e.productos[i] = p;
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }
        public static Estante operator -(Estante e, Producto p)
        {
            if (e == p)
            {
                for (int i = 0; i < e.productos.Length; i++)
                {
                    if (e.productos[i] == p)
                    {
                        e.productos[i] = null;
                        break;
                    }
                }
            } 
                return e;
        }
    }
}
