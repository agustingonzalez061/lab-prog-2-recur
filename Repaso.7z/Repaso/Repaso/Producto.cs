﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.marca = marca;
            this.codigoDeBarra = codigo;
            this.precio = precio;
        }

        public float GetPrecio()
        { return this.precio; }
        public string GetMarca()
        { return this.marca;}
        public static string MostrarProducto (Producto p1)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("PRODUCTO");
            sb.AppendLine("Marca :" + p1.GetMarca());
            sb.AppendLine("Precio : " + p1.GetPrecio());
            sb.AppendLine("Codigo : " + p1.codigoDeBarra);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        public static bool operator ==(Producto p1, Producto p2)
        {
            bool valor = false;
            if (!object.Equals(p1, null) && !object.Equals(p2, null))
            {
                if (p1.marca == p2.marca && p1.codigoDeBarra == p2.codigoDeBarra)
                {
                    valor = true;
                }
            }
            return valor;
        }

        public static bool operator !=(Producto p1, Producto p2)
        {

            return !(p1 == p2);
        }
        public static bool operator ==(Producto p1, String marca)
        {
            bool valor = false;
            if (!object.Equals(p1, null) && !object.Equals(marca, null))
            {
                if (p1.marca == marca)
                {
                    valor = true;
                }
            }
            return valor;
        }

        public static bool operator !=(Producto p1, String marca)
        {

            return !(p1 == marca);
        }
        public static explicit operator string (Producto p)
        {
            return p.codigoDeBarra;
        }


    }
}
