using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> productos;
    private List<Venta> ventas;
    public Comiqueria ()
    {
      this.productos = new List<Producto>();
      this.ventas = new List<Venta>();
    }
    public Producto this[Guid codigo]
    {
      get
      {       
        foreach (Producto item in productos)
        {
          if (codigo == (Guid)item)
          {
            return item;
          }         
        }
        return null;
      }
    }
    public static bool operator ==(Comiqueria comiqueria,Producto producto)
    {
      bool valor = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item.Descripcion == producto.Descripcion)
            valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria == producto);
    }
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      bool esta = false;
      if (!object.Equals(comiqueria, null) && !object.Equals(producto, null))
      {
        foreach (Producto item in comiqueria.productos)
        {
          if (item == producto)
            esta = true;
            break;
        }
        if (!esta)
          comiqueria.productos.Add(producto);
      }
      return comiqueria;
    }
    public void Vender (Producto producto) 
    {
         Vender(producto, 1);
    }
    public void Vender(Producto producto,int cantidad)
    {
      Venta venta = new Venta(producto, cantidad);
      ventas.Add(venta);
    }
    public string ListarVentas ()
    {
      StringBuilder sb = new StringBuilder();
      this.ventas.Sort(Comparar);
      foreach (Venta item in this.ventas)
      {
        sb.AppendLine(item.ObtenerDescripcionBreve());
      }
      sb.AppendLine("------------------------------------------");
      return sb.ToString();
    }
    private int Comparar(Venta v1, Venta v2)
    {
            if (v1.Fecha > v2.Fecha)
            {
                return 1;
            }
            else if (v1.Fecha < v2.Fecha)
            {
                return -1;
            }
            return 0;
        }
        public Dictionary<Guid,string> ListarProductos()
    {
      Dictionary<Guid, string> dic= new Dictionary<Guid, string>();
      foreach (Producto item in this.productos)
      {
        dic.Add((Guid)item, item.Descripcion);
        
      }
      return dic;
    }

  }
}
