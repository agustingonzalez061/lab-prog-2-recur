using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public sealed class Venta
  {
    private DateTime fecha;
    private static int porcentajeIva;
    private double precioFinal;
    private Producto producto;

    internal DateTime Fecha
    {
      get
      {
        return this.fecha;
      }
    }
    static Venta()
    {
      porcentajeIva = 21;
    }
    internal Venta (Producto producto,int cantidad)
    {
      this.producto = producto;
      Vender(cantidad);
    }
    
    public static double CalcularPrecioFinal (double precioUnidad, int cantidad)
    {
      double resultado = 0;
      double multi = 0;
      multi = precioUnidad * cantidad;
      resultado = multi * porcentajeIva;
      resultado = multi + (resultado / 100);    
      return resultado;
    }
    public string ObtenerDescripcionBreve()
    {
      return String.Format("{0} -- {1} -- {2}", this.fecha.ToString(), this.producto.Descripcion, string.Format("{0:#.##}", this.precioFinal));
    }
    private void Vender (int cantidad)
    {
      this.producto.Stock = this.producto.Stock - cantidad;
      this.fecha = DateTime.Now;
      this.precioFinal =CalcularPrecioFinal(this.producto.Precio, cantidad);
    }
  }
}
