using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Local : Llamada
    {
        protected float costo;

        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }
        public Local (Llamada llamada, float costo) :this (llamada.NroDestino,llamada.Duracion, llamada.NroOrigen,costo)
        {
           
        }
        public Local(string origen, float duracion, string destino, float costo) : base(duracion,destino,origen)
        {
          this.costo = costo;
        }
        protected override string Mostrar ()
        {
            base.Mostrar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Costo: " + CostoLlamada);
            return sb.ToString();
        }
        private float CalcularCosto ()
        {
            float valor = -1;
            if (!(Equals(base.Duracion, null) && Equals(this.costo, null)))
            {
                valor = base.Duracion * this.costo;
            }
            return valor;
        }
    public override bool Equals(object obj)
    {
      if (obj is Local)
        return true;
      return false;
    }
    public override string ToString()
    {
      return Mostrar();
    }
  }
}
