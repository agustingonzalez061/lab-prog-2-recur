using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Provincial : Llamada
    {
        public enum Franja { Franja_1,Franja_2,Franja_3}
        private Franja franjaHoraria;
        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }
        public Provincial(Franja miFranja,Llamada llamada) : this(llamada.NroOrigen, miFranja,llamada.Duracion,llamada.NroDestino )
        {
           
        }
        public Provincial(string origen,Franja miFranja, float duracion, string destino) : base(duracion,destino,origen)
        {
           this.franjaHoraria = miFranja;
        }
        protected override string Mostrar()
        {
            base.Mostrar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Costo: " + CostoLlamada);
            sb.AppendLine("Franja horaria" + franjaHoraria);
            return sb.ToString();
        }
        private float CalcularCosto()
        {
            float valor = -1;
            if (!(Equals(base.Duracion, null) && Equals(this.franjaHoraria, null)))
            {
                switch (franjaHoraria)
                {
                    case Franja.Franja_1:
                        valor = base.Duracion * 0.99f;
                        break;
                    case Franja.Franja_2:
                        valor = base.Duracion * 1.25f;
                        break;
                    case Franja.Franja_3:
                        valor = base.Duracion * 0.66f;
                        break;
                    default:
                        break;

                }
            }
            return valor;
        }
    public override bool Equals(object obj)
    {
      if (obj is Provincial)
        return true;
      return false;
    }
    public override string ToString()
    {
      return Mostrar();
    }
  }
}
