using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Llamada
    {
        public enum TipoLlamada {Local, Provincial, Todas }
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;


        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        public abstract float CostoLlamada { get; }

    public Llamada (float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroOrigen = nroOrigen;
            this.nroDestino = nroDestino;
        }
        protected virtual string Mostrar ()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("LLAMADA");
            sb.AppendLine("Duracion :" + duracion);
            sb.AppendLine("Nro Origen :" + nroOrigen);
            sb.AppendLine("Nro Destino :" + nroDestino);
            return sb.ToString();
        }
        public static int OrdenarPorDuracion (Llamada llamada1, Llamada llamada2)
        {
            int valor = -2;
            if(!(Equals(llamada1,null) && Equals(llamada2,null)))
            {
                if (llamada1.Duracion != llamada2.Duracion)
                {
                    if (llamada1.Duracion > llamada2.Duracion)
                    {
                        valor = 1;
                    }
                    else
                       valor = -1;
                }
                else
                    valor = 0;

            }
            return valor;
        }
    public static bool operator ==(Llamada l1, Llamada l2)
    {
      bool valor = false;
      if (object.Equals(l1.NroDestino, l2.nroDestino) && object.Equals(l1.NroOrigen,l2.NroOrigen))
      {
        valor = true;
      }
      return valor;
    }
    public static bool operator !=(Llamada l1, Llamada l2)
    {
      return !(l1 == l2);
    }
  }
}
