﻿namespace FrmMenu
{
  partial class FrmMenu
  {
    /// <summary>
    /// Variable del diseñador necesaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Limpiar los recursos que se estén usando.
    /// </summary>
    /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Código generado por el Diseñador de Windows Forms

    /// <summary>
    /// Método necesario para admitir el Diseñador. No se puede modificar
    /// el contenido de este método con el editor de código.
    /// </summary>
    private void InitializeComponent()
    {
            this.BtnGenerarLLamada = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnGenerarLLamada
            // 
            this.BtnGenerarLLamada.Location = new System.Drawing.Point(12, 12);
            this.BtnGenerarLLamada.Name = "BtnGenerarLLamada";
            this.BtnGenerarLLamada.Size = new System.Drawing.Size(248, 44);
            this.BtnGenerarLLamada.TabIndex = 0;
            this.BtnGenerarLLamada.Text = "Generar Llamada";
            this.BtnGenerarLLamada.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 78);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(248, 44);
            this.button2.TabIndex = 1;
            this.button2.Text = "Facturacion Total";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 141);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(248, 44);
            this.button3.TabIndex = 2;
            this.button3.Text = "Facturacion Local";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 202);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(248, 44);
            this.button4.TabIndex = 3;
            this.button4.Text = "Facturacion Provincial";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 265);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(248, 44);
            this.button5.TabIndex = 4;
            this.button5.Text = "Salir";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 324);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BtnGenerarLLamada);
            this.Name = "FrmMenu";
            this.Text = "Central Telefonica";
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button BtnGenerarLLamada;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button5;
  }
}

