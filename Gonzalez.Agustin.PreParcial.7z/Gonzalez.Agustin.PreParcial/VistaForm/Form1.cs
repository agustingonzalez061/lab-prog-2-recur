﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    public partial class Form1 : Form
    {
        private int contador;
        private DirectorTecnico director;
        public Form1()
        {
            InitializeComponent();
            contador = 0;
        }

        private void buttonCrear_Click(object sender, EventArgs e)
        {
            director = new DirectorTecnico (textBoxNombre.Text,textBoxApellido.Text, (int)numericUpDownEdad.Value, (int)numericUpDownDni.Value,(int)numericUpDownExperiencia.Value);
            MessageBox.Show("DT CREADO");
            contador++;
        }

        private void buttonValidar_Click(object sender, EventArgs e)
        {
            if(contador <= 0 )
                MessageBox.Show("Aún no se ha creado el DT del formulario");
            else if(director.validarAptitud())
                MessageBox.Show("El DT es apto");
            else
                MessageBox.Show("El DT no es apto");
        }
    }
}
