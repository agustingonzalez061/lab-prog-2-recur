﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region ATRIBUTOS
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private string nombre;
        #endregion
        #region PROPIEDADES
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                directorTecnico = value;
                if (!directorTecnico.validarAptitud())
                    directorTecnico = null;
                    
            }
        }
        public string Nombre
        {
            get
            {
                return nombre;

            }
        }
        #endregion
        #region METODOS
        private Equipo ()
        {
            this.jugadores = new List<Jugador>();
        }
        public Equipo(string nombre) : this ()
        {
            this.nombre = nombre;
        }
        public static explicit operator string(Equipo p)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("EQUIPO :" + p.Nombre);
            sb.AppendLine("");
            if (!(Equals(p.directorTecnico, null)))
            {
                sb.AppendLine(p.directorTecnico.Mostrar());
            }
            else
                sb.AppendLine("Sin DT asignado");
            sb.AppendLine("");
            foreach (Jugador item in p.jugadores)
            {
                sb.AppendLine( item.Mostrar());
            }
            sb.AppendLine("------------------------------------------");
            return sb.ToString();
        }
        public static bool operator ==(Equipo e, Jugador j)
        {
            bool valor = false;
            if (!object.Equals(e, null) && !object.Equals(j, null))
            {
                foreach (Jugador item in e.jugadores)
                {
                    if (item == j)
                        valor = true;
                }
            }
            return valor;
        }
        public static bool operator !=(Equipo e, Jugador j)
        {
            return !(e == j);
        }
        public static Equipo operator +(Equipo e, Jugador j)
        {
            bool esta = false;
            if (!object.Equals(e, null) && !object.Equals(j, null))
            {
                foreach (Jugador item in e.jugadores)
                {
                    if (item == j)
                        esta = true;
                }
                if (!esta && e.jugadores.Count < Equipo.cantidadMaximaJugadores && j.validarAptitud())
                    e.jugadores.Add(j);
            }
            return e;
        }
        public static bool ValidarEquipo (Equipo e)
        {
            bool valor = false;
            int contadorAr = 0,contadorDef = 0,contadorCen = 0,contadorDel = 0;
            
            if (!object.Equals(e, null))
            {
                foreach (Jugador item in e.jugadores)
                {
                    if (item.Posicion == Posicion.Arquero)
                        contadorAr++;
                    else if (item.Posicion == Posicion.Defensor)
                        contadorDef++;
                    else if (item.Posicion == Posicion.Central)
                        contadorCen++;
                    else if (item.Posicion == Posicion.Delantero)
                        contadorDel++;

                }
                if((!object.Equals(e, null)) && e.jugadores.Count == Equipo.cantidadMaximaJugadores && contadorAr ==1 && contadorAr != 0 && contadorDef != 0 && contadorDel != 0 && contadorCen != 0)
                {
                    valor = true;
                }
            }
            return valor;
        }
        #endregion
    }
}
