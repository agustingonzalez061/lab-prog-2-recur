﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador : Persona
    {
        #region ATRIBUTOS
        private float altura;
        private float peso;
        Posicion posicion;
        #endregion
        #region PROPIEDADES
        public float Altura
        {
            get
            {
                return this.altura;

            }
        }
        public float Peso
        {
            get
            {
                return this.peso;

            }
        }
        public Posicion Posicion
        {
            get
            {
                return this.posicion;

            }
        }
        #endregion
        #region METODOS
        public Jugador (string nombre,string apellido,int edad,int dni,float peso,float altura,Posicion posicion) : base(nombre, apellido, edad, dni)
        {
            this.posicion = posicion;
            this.peso = peso;
            this.altura = altura;
        }
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine("Altura :" + Altura);
            sb.AppendLine("Peso :" + Peso);
            sb.AppendLine("Posicion :" + Posicion);
            return sb.ToString();
        }
        public bool ValidarEstadoFisico()
        {
            bool valor = false;
            float imc;
            if (!(Equals(Peso, null) && Equals(Altura, null)))
            {
                imc = (Peso / (Altura * 2));
                if(imc >= 18.5 && imc <=25)
                {
                    valor = true;
                }
            }
            return valor;
        }
        public override bool validarAptitud()
        {
            bool valor = false;
            if (!(Equals(base.Edad, null)))
            {
                if (this.ValidarEstadoFisico() && base.Edad <= 40)
                {
                    valor = true;
                }
            }
            return valor;
        }
    }
        #endregion
        
}
