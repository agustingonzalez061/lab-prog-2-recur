﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region ATRIBUTOS
        private string apellido;
        private string nombre;
        private int dni;
        private int edad;
        #endregion
        #region PROPIEDADES
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        public int Dni
        {
            get
            {
                return this.dni;

            }
        }
        public int Edad
        {
            get
            {
                return this.edad;
            }
        }
        #endregion
        #region METODOS
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Apellido :" + Apellido);
            sb.AppendLine("Nombre :" + Nombre);
            sb.AppendLine("Edad :" + Edad);
            sb.AppendLine("Dni :" + Dni);
            return sb.ToString();
        }
        public Persona(string nombre, string apellido, int edad, int dni)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.edad = edad;
            this.dni = dni;
        }
        public abstract bool validarAptitud();
        #endregion
    }
}
