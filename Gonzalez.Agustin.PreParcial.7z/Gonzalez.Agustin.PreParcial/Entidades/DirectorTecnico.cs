﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        #region ATRIBUTOS
        private int añosExperiencia;
        #endregion
        #region PROPIEDADES
        public int AñosExperiencia
        {
            get
            {
                return this.añosExperiencia;

            }
        }
        #endregion
        #region METODOS
        public DirectorTecnico (string nombre, string apellido, int edad, int dni, int añosExperiencia) : base (nombre,apellido,edad,dni)
        {
            this.añosExperiencia = añosExperiencia;
        }
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine("Años de experiencia :" + AñosExperiencia);
            return sb.ToString();
        }

        public override bool validarAptitud()
        {
            bool valor = false;
            if (!(Equals(this.AñosExperiencia, null) && Equals(base.Edad, null)))
            {
                if (this.AñosExperiencia >= 2 && base.Edad < 65)
                {
                    valor = true;
                }

            }
            return valor;
        }
        #endregion
    }
}
