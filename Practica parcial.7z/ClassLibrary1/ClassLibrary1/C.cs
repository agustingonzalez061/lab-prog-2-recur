﻿public enum EConector
{
    PCIExpress,
    USB,
    MiniUSB,
    MicroUSB,
    PS2
}
