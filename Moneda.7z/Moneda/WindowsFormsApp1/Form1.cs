﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Billetes;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnConvertEuro_Click(object sender, EventArgs e)
        {
            Euro euro = (double.Parse(txtEuro.Text));
            Dolar dolar = ((Dolar) euro);
            Pesos pesos = ((Pesos)euro);

            txtEuroAEuro.Text = euro.GetCantidad().ToString();
            txtEuroADolar.Text = dolar.GetCantidad().ToString();
            txtEuroAPesos.Text = pesos.GetCantidad().ToString();

        }

        private void btnConvertDolar_Click(object sender, EventArgs e)
        {
            Dolar dolar = (double.Parse(txtDolar.Text));
            Euro euro = ((Euro)dolar);           
            Pesos pesos = ((Pesos)dolar);

            txtDolarAEuro.Text = euro.GetCantidad().ToString();
            txtDolarADolar.Text = dolar.GetCantidad().ToString();
            txtDolarAPesos.Text = pesos.GetCantidad().ToString();
        }

        private void btnConvertPesos_Click(object sender, EventArgs e)
        {
            Pesos pesos = (double.Parse(txtPesos.Text));
            Dolar dolar = ((Dolar) pesos);
            Euro euro = ((Euro)pesos);


            txtPesosAEuro.Text = euro.GetCantidad().ToString();
            txtPesosADolar.Text = dolar.GetCantidad().ToString();
            txtPesosAPesos.Text = pesos.GetCantidad().ToString(); 
        }
    }
}
